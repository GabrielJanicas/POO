package aula02;

public class util {
	
}
