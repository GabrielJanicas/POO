package aula09.Ex3;

public class Plane {
}
