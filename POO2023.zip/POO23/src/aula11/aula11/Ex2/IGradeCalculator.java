package aula11.Ex2;
import java.util.List;

public interface IGradeCalculator {

    double calculate(List<Double> grades);
}
